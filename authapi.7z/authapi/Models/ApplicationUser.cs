﻿using Microsoft.AspNetCore.Identity;

namespace authapi.Models;

public class ApplicationUser : IdentityUser
{
}
